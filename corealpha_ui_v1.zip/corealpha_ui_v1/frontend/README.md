# CoreAlpha UI placeholder

This placeholder UI package is unpacked by the automation workflow.
