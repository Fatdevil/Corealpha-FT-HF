from fastapi.testclient import TestClient
from app import app
client = TestClient(app)

def test_health():
    r = client.get('/health'); assert r.status_code==200; assert r.json()['ok'] is True

def test_flow():
    s = client.post('/summarize', json={'ticker':'NVDA','text':'strong growth and record margins'}).json()
    se = client.post('/sentiment', json={'ticker':'NVDA','texts':[s['summary']]}).json()
    props = []
    for a in ['Sentiment','Fundamental','Technical']:
        pr = client.post('/agent/propose', json={'ticker':'NVDA','agent':a,'sentiment':se['score']}).json()
        props.append({k: pr[k] for k in ['agent','vote','weight','confidence']})
    v = client.post('/vote', json={'proposals': props}).json()
    assert v['decision'] in ['BUY','HOLD','SELL']
