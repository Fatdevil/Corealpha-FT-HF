# CoreAlpha End-to-End v1.1 — Adapter + UI

Se `backend/README.md` för detaljer. Starta backend och öppna `ui/index.html`.
